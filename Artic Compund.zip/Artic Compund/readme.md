# Artic Compound 

<hr>

## Loot

- Locked Crate
- 4 Elite Crates
- 8 Guaranteed Mili Crate
- 2 random crates
- ~15 Assorted lootables (misc crates)
- 3 Diesel Barrels

<hr>

## General Info

- Building Block (150m)
- Outside Rads Med (130m)
- Inside Red Hanger rads High

<hr>

# NPCS

Heavy Scientists and Normal Scientists armed with LR and M9 are scattered throughout the compound and inside the hanger.
